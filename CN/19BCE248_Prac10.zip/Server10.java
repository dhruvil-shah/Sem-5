import java.io.*;
import java.net.*;
public class Server10 {   
    public static void main(String args[])throws IOException
    { 

             System.out.println("Note:Please adjust file path according to your local machine");
             System.out.println("Waiting for Connection to be established");
        ServerSocket ss=null;
        try
        {  
            ss=new ServerSocket(8081);
        }
        catch(IOException e)
        { 
            System.out.println("couldn't listen");
            System.exit(0);
        }
        Socket cs=null;
        try
        { 
            cs=ss.accept();
            System.out.println("Connection established"+cs);
        }
        catch(Exception e)
        { 
            System.out.println("Accept failed");
            System.exit(1);
        } 
        //Input and output stream declaration for reading and writing input to and from the client
        PrintWriter put=new PrintWriter(cs.getOutputStream(),true);
        BufferedReader st=new BufferedReader(new InputStreamReader(cs.getInputStream()));
        String s=st.readLine();
        //Taking the filename from client side.
        System.out.println("The requested file is : "+s);
        File f=new File(s);
        if(f.exists())
        { 
            //Reading file line by line and tranferring it to client.
            BufferedReader d=new BufferedReader(new FileReader(s));
            String line;
            while((line=d.readLine())!=null)
            {
                put.write(line);
                put.flush();
            }
            d.close();
            System.out.println("File transfered");
            cs.close();
            ss.close();
        }  
    }  
}