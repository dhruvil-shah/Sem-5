import java.net.*;
import java.io.*;
class Client10 {
    public static void main(String srgs[])throws IOException
    {
        Socket s=null;
        BufferedReader get=null;
        PrintWriter put=null;
        try
        { 
            //First of all making connection with the server side by making server on first and then the client
            s=new Socket("127.0.0.1",8081);
            //Declaring the input and output stream from and to the server
            get=new BufferedReader(new InputStreamReader(s.getInputStream()));
            put=new PrintWriter(s.getOutputStream(),true);
        }  
        catch(Exception e)
        {
            System.exit(0);
        }
        String u,f;
        //Taking file to be tranfer
        System.out.println("Enter the file name to transfer from server:");
        DataInputStream dis=new DataInputStream(System.in);
        //Reading file name
        f=dis.readLine();
        //As the file name is passed server will read the file and tranfer content to the client.
        put.println(f);
        //Now client will make a new file and copy the content which is recieved from server.
        File f1=new File("D:\\SEM 5\\CN\\out.txt");
        FileOutputStream  fs=new FileOutputStream(f1);
        //Copying the content to new file named out.txt
        byte nl[]={'\n'};
        while((u=get.readLine())!=null)
        { 
            byte jj[]=u.getBytes();
            fs.write(jj);
            fs.write(nl);

        }
        fs.close();
        System.out.println("File received");
        s.close();
    }
}